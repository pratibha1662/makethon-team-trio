$("#search").click(function(){
    var place = document.getElementsByName("place")[0];
    var centre = $(".location")[0];
    var phone=$(".phone-no")[0];
    var places = {
        "Punjab": {
            "location": "C/O HANSOL CSN LOGISTICS INDIA P LTD, C/O SAMRA POULTRY PRODUCTS (P) L, SANEHWAL - KOHARA ROAD, SANEHWAL, LUDHIANA, PUNJAB - 141120",
            "phone": 8283044227,
        },
        "Haryana": {
            "location": "SAMSUNG INDIA ELECTRONICS PRIVATE LTD., C/O APOLLO SUPPLY CHAIN PVT. LTD., KHASRA NO. 37/1/1, REVENUEOF VILLAGE KHANPUR, AMBALA, HARYANA -133102",
            "phone": 9876636732,
        },
        "Madhya Pradesh": {
            "location": "SAMSUNG INDIA ELECTRONICS PRIVATE LIMITED, C/O FEDEX TSCS (I) PVT LTD., SURVEY NO. 307, GRAM MANGLIA SADAK, BY PASS ROAD OPP. OMEX CITY-2, OPP. HUL WAREHOUSE, MANGLIA, INDORE, MADHYA PRADESH - 453771",
            "phone": "8103734777 / 9752594289",
        },
        "Bengaluru": {
            "location": "E-Parisaraa Private Limited,No.B - 41 / 1, 3rd Stage,Peenya Industrial Estate,Bengaluru",
            "phone": 9894820412,
        },
        "Jharkhand": {
            "location": "SAMSUNG INDIA ELECTRONICS (P) LTD., C/O SATYAM SALES CORPORATION, VINAIKA CAMPUS, PLOT.1063, SIDRAUL, NAMKUM, RANCHI, JHARKHAND -834010",
            "phone": 9771427387,
        },

    }
    place = place.value;
    centre.innerHTML += places[place].location;
    phone.innerHTML +=  places[place].phone;
    document.getElementsByClassName("location")[0].style.display="block";
    document.getElementsByClassName("phone-no")[0].style.display = "block";
});